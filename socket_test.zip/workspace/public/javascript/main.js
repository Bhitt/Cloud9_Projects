 var socket;
 
 socket = io.connect('https://socket-test-bhitt.c9users.io:8080');